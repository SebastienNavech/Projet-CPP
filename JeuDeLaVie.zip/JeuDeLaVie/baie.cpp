#include "baie.h"

int Baie::baie = 0;

Baie::Baie(Position _pos) : Element("Baie", _pos), Ressource("Baie", _pos){ baie++; }

Baie::~Baie(){}

void Baie::agir(){}

void Baie::evolvNbBaie(int nb){ baie += nb; }

int Baie::getBaie(){ return baie; }
