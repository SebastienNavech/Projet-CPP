#include <QApplication>
#include <QtGui>

#include "configurationWindow.h"
#include "gameWindow.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    configurationWindow config;
    config.exec();

    gameWindow game;
    game.show();

    return app.exec();
}
