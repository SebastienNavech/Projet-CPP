#include "mobile.h"
#include "gaulois.h"
#include "homme.h"
#include "femme.h"
#include "enfant.h"
#include "romain.h"

Mobile::Mobile(string _nom, Position _pos, int _age, Monde & _mde) : Element(_nom, _pos){
    vitesse = rand() % VITESSE_MAX + VITESSE_MIN;
    vue = rand() % VUE_MAX + VUE_MIN;
    force = rand() % FORCE_MAX + FORCE_MIN;
    vie = rand() % VIE_MAX + VIE_MIN;
    esperance = rand() % ESPERANCE_MAX + ESPERANCE_MIN;
    age = _age;
    mde = &_mde;
}

Position Mobile::vision(const type_info & _type) const{
    int i = 1, j;
    Position p;
    while(i <= vue){
        p.setX(getPosition().getX()-i);
        p.setY(getPosition().getY()-i);
        if((Position::positionCorrecte(p.getX(), p.getY()))&&(!mde->caseVide(p.getX(), p.getY()))&&(typeid(*mde->at(mde->getCarte().find(p)->second)) == _type)){
            return p;
        }
        j = 0;
        while(j < i){
            p = mde->caseSuivante(p, SENS_NO, SENS_PP*SENS_DBLE);
            if((Position::positionCorrecte(p.getX(), p.getY()))
               &&(!mde->caseVide(p.getX(), p.getY()))
               &&(typeid(*mde->at(mde->getCarte().find(p)->second)) == _type)){
                return p;
            }
            j++;
        }
        j = 0;
        while(j < i){
            p = mde->caseSuivante(p, SENS_PP, SENS_PP);
            if((Position::positionCorrecte(p.getX(), p.getY()))
               &&(!mde->caseVide(p.getX(), p.getY()))
               &&(typeid(*mde->at(mde->getCarte().find(p)->second)) == _type)){
                return p;
            }
            j++;
        }
        j = 0;
        while(j < i){
            p = mde->caseSuivante(p, SENS_PP, SENS_MM);
            if((Position::positionCorrecte(p.getX(), p.getY()))
               &&(!mde->caseVide(p.getX(), p.getY()))
               &&(typeid(*mde->at(mde->getCarte().find(p)->second)) == _type)){
                return p;
            }
            j++;
        }
        j = 0;
        while(j < i){
            p = mde->caseSuivante(p, SENS_NO, SENS_MM*SENS_DBLE);
            if((Position::positionCorrecte(p.getX(), p.getY()))
               &&(!mde->caseVide(p.getX(), p.getY()))
               &&(typeid(*mde->at(mde->getCarte().find(p)->second)) == _type)){
                return p;
            }
            j++;
        }
        j = 0;
        while(j < i){
            p = mde->caseSuivante(p, SENS_MM, SENS_MM);
            if((Position::positionCorrecte(p.getX(), p.getY()))
               &&(!mde->caseVide(p.getX(), p.getY()))
               &&(typeid(*mde->at(mde->getCarte().find(p)->second)) == _type)){
                return p;
            }
            j++;
        }
        j = 1;
        while(j < i){
            p = mde->caseSuivante(p, SENS_MM, SENS_PP);
            if((Position::positionCorrecte(p.getX(), p.getY()))
               &&(!mde->caseVide(p.getX(), p.getY()))
               &&(typeid(*mde->at(mde->getCarte().find(p)->second)) == _type)){
                return p;
            }
            j++;
        }
        i++;
    }

    return Position(0, 0);

}

void Mobile::evolution(){
    if(Gaulois::getFood() <= 0){
        vie -= 1;
    }
    age++;
    if((age >= esperance)||(vie <= 0)){
        if(typeid(*this) == typeid(Homme)){ Gaulois::evolvNbHomme(-1); }
        else{
            if(typeid(*this) == typeid(Femme)){ Gaulois::evolvNbFemme(-1); }
            else{
                if(typeid(*this) == typeid(Enfant)){ Gaulois::evolvNbEnfant(-1); }
                else{
                    if(typeid(*this) == typeid(Romains)){ Romains::evolvNbPredateur(-1); }
                }
            }
        }
        if(mde->getCarte().find(getPosition()) != mde->getCarte().end()){
            mde->getCarte().erase(getPosition());
        }
        setPosition(Position(0, 0));
    }

}

//G�n�ration al�atoire de position
Position Mobile::genAleatDeplacement() const{
    int nbRand = 0;
    int x = -1, y = -1;
    while((nbRand < 100)&&((!Position::positionCorrecte(x, y))||(!mde->caseVide(x, y))))
    {
        x = getPosition().getX() + rand() % (2*getVitesse()+1) - getVitesse();
        y = getPosition().getY() + rand() % (2*getVitesse()+1) - getVitesse();
        nbRand++;
    }
    if(nbRand < 100){ return Position(x, y); }
    else{ return Position(0, 0); }
}

void Mobile::bouger(Position p, unsigned int indexRessource){
    unsigned int indexGaulois = mde->getCarte().find(getPosition())->second;
    mde->at(indexRessource)->setPosition(Position(0, 0));
    mde->getCarte().erase(p);
    mde->getCarte().erase(getPosition());
    mde->getCarte().insert(pair<Position, unsigned int>(p, indexGaulois));
    mde->at(indexGaulois)->setPosition(p);
}

void Mobile::bougerRandom(){
    unsigned int indexMobile;
    Position p;
    p = Mobile::genAleatDeplacement();
    if(p.getX() != 0){
        //pour se d�placer vers une nouvelle position
        indexMobile = mde->getCarte().find(getPosition())->second;
        mde->getCarte().erase(getPosition());
        mde->getCarte().insert(pair<Position, unsigned int>(p, indexMobile));
        mde->at(indexMobile)->setPosition(p);
    }
}



void Mobile::setVitesse(int _vitesse){ vitesse = _vitesse; }
void Mobile::setForce(int _force){ force = _force; }
void Mobile::setVue(int _vue){ vue = _vue; }
void Mobile::setVie(int _vie){ vie = _vie; }
void Mobile::setAge(int _age){ age = _age; }

int Mobile::getVitesse()const{ return vitesse; }
int Mobile::getForce()const{ return force; }
int Mobile::getVue()const{ return vue; }
int Mobile::getVie()const{ return vie; }
int Mobile::getAge()const{ return age; }
int Mobile::getEsperance()const{ return esperance; }
