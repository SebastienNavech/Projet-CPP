#include "romain.h"

int Romains::predateur = 0;

Romains::Romains(string _nom, Position _pos, Monde &_mde) : Element(_nom, _pos), Mobile(_nom, _pos, AGE_ADULTE, _mde){
    predateur++;
}

void Romains::agir(){
    Position p(0, 0);
    unsigned int indexGaulois;
    evolution();
    if(Position::positionCorrecte(getPosition())){
        p = vision(typeid(Homme*));
        if(p.getX() == 0){
            p = vision(typeid(Femme*));
        }
        if(p.getX() != 0){
            indexGaulois = mde->getCarte().find(p)->second;
            bouger(p, indexGaulois); //Fait se battre avant le d�placement
        }
        else {
            bougerRandom();
        }
    }
}

void Romains::bouger(Position p, unsigned int indexGaulois){
    unsigned int indexRomains = mde->getCarte().find(getPosition())->second;
    //Fight :
    combattre(indexGaulois);

    //D�placement :
    if(getVie() <= 0){
        mde->getCarte().erase(getPosition());
        mde->at(indexRomains)->setPosition(Position(0, 0));
        evolvNbPredateur(-1);
    }
    else{

        if(typeid(*mde->at(indexGaulois)) == typeid(Homme)){ Gaulois::evolvNbHomme(-1); }
        else{ Gaulois::evolvNbFemme(-1); }
        mde->at(indexGaulois)->setPosition(Position(0, 0));
        mde->getCarte().erase(p);
        mde->getCarte().erase(getPosition());
        mde->getCarte().insert(pair<Position, unsigned int>(p, indexRomains));
        mde->at(indexRomains)->setPosition(p);
    }
}

void Romains::combattre(unsigned int indexGaulois){
    while((getVie() > 0)&&((dynamic_cast<Mobile*>(mde->at(indexGaulois))->getVie() > 0))){
        dynamic_cast<Mobile*>(mde->at(indexGaulois))->setVie(dynamic_cast<Mobile*>(mde->at(indexGaulois))->getVie() - getForce());
        setVie(getVie() - dynamic_cast<Mobile*>(mde->at(indexGaulois))->getForce());
    }
}

void Romains::setNbPredateur(int _pre){ predateur = _pre; }

int Romains::getNbPredateur(){ return predateur; }

void Romains::evolvNbPredateur(int nb){ predateur += nb; }
