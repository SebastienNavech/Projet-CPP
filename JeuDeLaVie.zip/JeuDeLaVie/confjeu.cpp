#include "confjeu.h"

int ConfJeu::critic_food = CF_RESSOURCE_CRITIC;
int ConfJeu::critic_wood = CF_RESSOURCE_CRITIC;
int ConfJeu::food_init = CF_RESSOURCE_CRITIC;
int ConfJeu::wood_init = CF_RESSOURCE_CRITIC;
int ConfJeu::homme_min = CF_PEUPLE_HOMME_MIN;
int ConfJeu::femme_min = CF_PEUPLE_FEMME_MIN;
int ConfJeu::lapin_min = CF_FOOD_REPOP;
int ConfJeu::baie_min = CF_FOOD_REPOP;
int ConfJeu::arbre_min = CF_WOOD_REPOP;
int ConfJeu::food_pop = CF_FOOD_REPOP;
int ConfJeu::wood_pop = CF_WOOD_REPOP;
int ConfJeu::romain_pop = CF_PREDATEUR_REPOP;


ConfJeu::ConfJeu()
{
}

void ConfJeu::init(){}

void ConfJeu::setCritic_food(int nb){ critic_food = nb; }
void ConfJeu::setCritic_wood(int nb){ critic_wood = nb; }
void ConfJeu::setFood_init(int nb){ food_init = nb; }
void ConfJeu::setWood_init(int nb){ wood_init = nb; }
void ConfJeu::setHomme_min(int nb){ homme_min = nb; }
void ConfJeu::setFemme_min(int nb){ femme_min = nb; }
void ConfJeu::setLapin_min(int nb){ lapin_min = nb; }
void ConfJeu::setBaie_min(int nb){ baie_min = nb; }
void ConfJeu::setArbre_min(int nb){ arbre_min = nb; }
void ConfJeu::setFood_pop(int nb){ food_pop = nb; }
void ConfJeu::setWood_pop(int nb){ wood_pop = nb; }
void ConfJeu::setRomain_pop(int nb){ romain_pop = nb; }

int ConfJeu::getCritic_food() { return critic_food; }
int ConfJeu::getCritic_wood() { return critic_wood; }
int ConfJeu::getFood_init() { return food_init; }
int ConfJeu::getWood_init() { return wood_init; }
int ConfJeu::getHomme_min() { return homme_min; }
int ConfJeu::getFemme_min() { return femme_min; }
int ConfJeu::getLapin_min() { return lapin_min; }
int ConfJeu::getBaie_min() { return baie_min; }
int ConfJeu::getArbre_min() { return arbre_min; }
int ConfJeu::getFood_pop() { return food_pop; }
int ConfJeu::getWood_pop() { return wood_pop; }
int ConfJeu::getRomain_pop() { return romain_pop; }
