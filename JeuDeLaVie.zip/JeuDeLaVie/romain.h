#ifndef ROMAIN_H
#define ROMAIN_H

#include "const.h"
#include <typeinfo>
#include "mobile.h"
#include "ressource.h"
#include "gaulois.h"
#include "homme.h"
#include "femme.h"
#include "monde.h"

class Romains : public virtual Mobile
{
    private :
        static int predateur;
    public:
        Romains(string, Position, Monde &);
        void agir();
        void bouger(Position, unsigned int);
        void combattre(unsigned int);
        void setNbPredateur(int);
        static int getNbPredateur();
        static void evolvNbPredateur(int nb);
};

#endif // ROMAIN_H
