#ifndef CONFIGURATIONWINDOW_H
#define CONFIGURATIONWINDOW_H

#include <QtGui>
#include "confjeu.h"
#include "gaulois.h"

class configurationWindow : public QDialog
{
    Q_OBJECT

    public:
        configurationWindow();

    public slots:
        void closeAndSave();

};

#endif // CONFIGURATIONWINDOW_H
