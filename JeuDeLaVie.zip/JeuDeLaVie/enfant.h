#ifndef ENFANT_H
#define ENFANT_H

#include "gaulois.h"
#include "homme.h"
#include "baie.h"

class Enfant : public Gaulois
{
    public:
        Enfant(string, Position, Monde&);
        void agir();
};

#endif // ENFANT_H
