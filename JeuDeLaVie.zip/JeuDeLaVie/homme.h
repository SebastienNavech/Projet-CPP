#ifndef HOMME_H
#define HOMME_H

#include "gaulois.h"
#include "femme.h"
#include "lapin.h"
#include "arbre.h"

class Homme : public Gaulois
{
    public:
        Homme(string, Position, Monde&);
        void agir();
};

#endif // HOMME_H
