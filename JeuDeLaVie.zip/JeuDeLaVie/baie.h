#ifndef BAIES_H
#define BAIES_H
#include "ressource.h"

class Baie : public Ressource
{
    private :
        static int baie;
    public :
        Baie(Position);
        virtual ~Baie();
        virtual void agir();
        static void evolvNbBaie(int);
        static int getBaie();
};

#endif


