#ifndef GAMEWINDOW_H
#define GAMEWINDOW_H

#include <QtGui>
#include <dos.h>
#include <Windows.h>
#include <sstream>
#include "configurationwindow.h"
#include "const.h"
#include "monde.h"
#include "homme.h"
#include "femme.h"
#include "enfant.h"
#include "lapin.h"
#include "baie.h"
#include "arbre.h"
#include "romain.h"

class gameWindow : public QMainWindow
{
    Q_OBJECT

    public:
        gameWindow();
        Monde md;
        QLabel *label[21][21];
        void refreshView();
        QString nbGaulois;
        QString nbGauloises;
        QString nbEnfants;
        QString nbFood;
        QString nbWood;
        QString nbCycles;
        QLabel *labelNbGauloisVal;
        QLabel *labelNbGauloisesVal;
        QLabel *labelNbEnfantsVal;
        QLabel *labelNbFoodVal;
        QLabel *labelNbWoodVal;
        QLabel *labelNbCyclesVal;
        QTextEdit *console;

    public slots:
        void evolvedOneCycle();
        void evolvedTenCycle();
        void evolvedOneHundredCycle();
        void showInfos();
        void evolvedFin();
};

#endif // GAMEWINDOW_H
