#include "position.h"

Position::Position(){
    x = 1;
    y = 1;
}

Position::Position(int _x, int _y){
    x = _x;
    y = _y;
}

void Position::setX(int _x) { x = _x; }
void Position::setY (int _y) { y = _y; }

int Position::getX() const { return x; }
int Position::getY() const { return y; }

bool Position::positionCorrecte(int a, int b){
    return ((a > 0) && (b > 0) && (a <= LONGUEUR_MAP) && (b <= LARGEUR_MAP) && ((a % 2) == (b % 2)));
}
bool Position::positionCorrecte(Position p){
    return ((p.getX() > 0) && (p.getY() > 0) && (p.getX() <= LONGUEUR_MAP) && (p.getY() <= LARGEUR_MAP) && ((p.getX() % 2) == (p.getY() % 2)));
}

bool Position::operator <(const Position & p) const{
    return ((this->y < p.y) || ((this->y == p.y) && (this->x < p.x)));
}

bool Position::operator ==(const Position & p) const{
    return (this->x == p.x && this->y == p.y);
}
