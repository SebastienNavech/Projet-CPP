#ifndef MOBILES_H
#define MOBILES_H

#include <cstdlib>
#include "const.h"
#include "element.h"
#include "monde.h"

class Mobile : public virtual Element
{
    private :
        int vitesse;
        int vue;
        int force;
        int vie;
        int age;
        int esperance;

	public :
        Mobile(string, Position, int, Monde &);
        virtual void agir() = 0;
        void evolution();
        Position vision(const type_info &) const;
        Position genAleatDeplacement() const;
        void bouger(Position, unsigned int);
        void bougerRandom();
        void setVitesse(int);
        void setForce(int);
        void setVue(int);
        void setVie(int);
        void setAge(int);
        int getVitesse()const;
        int getForce()const;
        int getVue()const;
        int getVie()const;
        int getAge()const;
        int getEsperance()const;
    protected :
        Monde *mde;
};

#endif

