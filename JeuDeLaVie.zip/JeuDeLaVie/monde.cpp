#include "monde.h"
#include "mobile.h"
#include "gaulois.h"
#include "romain.h"
#include "arbre.h"
#include "baie.h"
#include "lapin.h"
#include "enfant.h"

int Monde::cycle = 0;
bool Monde::fin = false;

Monde::Monde(): vector<Element*>(), carte(){
    int i;
    Position pos;
    srand((unsigned int)time(NULL));

    for(i = 0; i < ConfJeu::getRomain_pop(); i++){
        pos = generationAleatMap();
        push_back(new Romains("Cesar", pos, *this));
        carte.insert(pair<Position, unsigned int>(pos, size()-1));
    }

    for(i = 0; i < ConfJeu::getHomme_min(); i++){
        pos = generationAleatMap();
        push_back(new Homme("Asterix", pos, *this));
        carte.insert(pair<Position, unsigned int>(pos, size()-1));
    }

    for(i = 0; i < ConfJeu::getFemme_min(); i++){
        pos = generationAleatMap();
        push_back(new Femme("Falbala", pos, *this));
        carte.insert(pair<Position, unsigned int>(pos, size()-1));
    }

    for(i = 0; i < ConfJeu::getArbre_min(); i++){
        pos = generationAleatMap();
        push_back(new Arbre(pos));
        carte.insert(pair<Position, unsigned int>(pos, size()-1));
    }

    for(i = 0; i < ConfJeu::getBaie_min(); i++){
        pos = generationAleatMap();
        push_back(new Baie(pos));
        carte.insert(pair<Position, unsigned int>(pos, size()-1));
    }

    for(i = 0; i < ConfJeu::getLapin_min(); i++){
        pos = generationAleatMap();
        push_back(new Lapin(pos, *this));
        carte.insert(pair<Position, unsigned int>(pos, size()-1));
    }
    //afficher();

}
/*
Monde::~Monde(){
    delete this;
}
*/
void Monde::evoluer(){
    trace.clear();
    unsigned int i;
    for(i = 0; i < size(); i++){
        if(Position::positionCorrecte(at(i)->getPosition())){
            if((typeid(*at(i)) == typeid(Enfant)) && (dynamic_cast<Mobile*>(at(i))->getAge() == 20)){
                if(rand()%2 == 0){ at(i) = new Homme("Obelix", at(i)->getPosition(), *this); }
                else{ at(i) = new Femme("Fanzine", at(i)->getPosition(), *this); }
                Gaulois::evolvNbEnfant(-1);
            }
            at(i)->agir();
            trace.append(at(i)->getTrace());
        }
    }
    if(Gaulois::getFood() < 0){ Gaulois::setFood(0); }
    if(Gaulois::getWood() < 0){ Gaulois::setWood(0); }

    cycle++;

    if((cycle % 10) == 0){
        rePeuplement();
    }
    if((cycle % 5) == 0){
        repack();
    }

    if((Gaulois::getHomme() == 0)&&(Gaulois::getFemme() == 0)&&(Gaulois::getEnfant() == 0)){ fin = true; }
    trace.append("Cycle : ");trace.append(QString("%1").arg(cycle));trace.append(".\n");

}

void Monde::repack(){
    unsigned int i;
    for(i = 0; i < size(); i++){
        if(!Position::positionCorrecte(at(i)->getPosition())){ supprimer(i); }
    }
    carte = map<Position, unsigned int>();
    for(i = 0; i < size(); i++){ carte.insert(pair<Position, unsigned int>(at(i)->getPosition(), i)); }
}

int Monde::getCycle(){ return cycle; }

void Monde::rePeuplement(){
    Position pos;
    int i;

    for(i = 0; i < ConfJeu::getWood_pop(); i++){
        pos = generationAleatMap();
        push_back(new Arbre(pos));
        carte.insert(pair<Position, unsigned int>(pos, size()-1));
    }

    for(i = 0; i < ConfJeu::getFood_pop(); i++){
        pos = generationAleatMap();
        push_back(new Lapin(pos, *this));
        carte.insert(pair<Position, unsigned int>(pos, size()-1));
    }

    for(i = 0; i < ConfJeu::getFood_pop(); i++){
        pos = generationAleatMap();
        push_back(new Baie(pos));
        carte.insert(pair<Position, unsigned int>(pos, size()-1));
    }

    for(i = 0; i < ConfJeu::getRomain_pop(); i++){
        pos = generationAleatMap();
        push_back(new Romains("Cesar", pos, *this));
        carte.insert(pair<Position, unsigned int>(pos, size()-1));
    }

}

void Monde::supprimer(const int & index){
    for(unsigned int i = index; i < size()-1; i++){ at(i) = at(i+1); }
    pop_back();
}

void Monde::afficher(){
    trace.clear();
    map<Position, unsigned int>::iterator it = carte.begin();
    unsigned int i;
    for(i = 0; i < size(); i++){
        if(Position::positionCorrecte(this->at(it->second)->getPosition().getX(), this->at(it->second)->getPosition().getY())){
            if((typeid(*at(i)) == typeid(Romains))||(typeid(*at(i)) == typeid(Homme))||(typeid(*at(i)) == typeid(Femme))||(typeid(*at(i)) == typeid(Enfant))){
                trace.append(QString("%1").arg(i));
                trace.append(", ");
                QString qstr = QString::fromStdString(this->at(i)->getNom());
                trace.append(qstr);
                trace.append(" : ");
                trace.append(QString("%1").arg(this->at(i)->getPosition().getX()));
                trace.append(", ");
                trace.append(QString("%1").arg(this->at(i)->getPosition().getY()));

                trace.append(", vie : ");
                trace.append(QString("%1").arg(dynamic_cast<Mobile*>(this->at(i))->getVie()));
                trace.append(", age : ");
                trace.append(QString("%1").arg(dynamic_cast<Mobile*>(this->at(i))->getAge()));
                trace.append(", esperance : ");
                trace.append(QString("%1").arg(dynamic_cast<Mobile*>(this->at(i))->getEsperance()));
                trace.append(".\n");
            }
        }
    }
    //Gaulois::afficherInfo();
}

bool Monde::caseVide(int x, int y){ return(carte.end() == carte.find(Position(x, y))); }

//sensX et sensY d�termine l'incr�ment ou le d�crement de la position
Position Monde::caseSuivante(Position actual, int sensX, int sensY){ return Position(actual.getX()+sensX, actual.getY()+sensY); }

map<Position, unsigned int>& Monde::getCarte(){ return carte; }

Position Monde::generationAleatMap(){
    int x = -1, y = -1;
    while((!Position::positionCorrecte(x, y))||(!caseVide(x, y))){
        x = rand() % LONGUEUR_MAP + DEBUT_MAP;
        y = rand() % LARGEUR_MAP + DEBUT_MAP;
    }
    return Position(x, y);
}

QString& Monde::getTrace(){
    return trace;
}

void Monde::faireNaitre(Position p){
    push_back(new Enfant("Catedralgotix", p, *this));
    carte.insert(pair<Position, unsigned int>(p, size()-1));
}

bool Monde::estFini(){
    return fin;
}

