#ifndef POSITIONS_H
#define POSITIONS_H

#include "const.h"
#include "confjeu.h"

class Position
{
    private :
		int x;
		int y;

	public :
        Position();
        Position(int, int);
        static bool positionCorrecte(int, int);
        static bool positionCorrecte(Position p);
        void setX(int);
        void setY(int);
        int getX() const;
        int getY() const;
        bool operator <(const Position &) const;
        bool operator ==(const Position & p) const;
};

#endif

