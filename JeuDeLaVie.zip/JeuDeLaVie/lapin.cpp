#include "lapin.h"

int Lapin::lapin = 0;

Lapin::Lapin(Position _pos, Monde & _mde): Element("Lapin", _pos), Mobile("Lapin", _pos, AGE_ADULTE, _mde), Ressource("Lapin", _pos){
    lapin++;
}

void Lapin::agir(){
    Position p(0, 0);
    p = Mobile::genAleatDeplacement();
    if(p.getX() != 0){ bougerRandom(); }
}

void Lapin::evolvNbLapin(int nb){ lapin += nb; }

int Lapin::getLapin(){ return lapin; }
