#include "enfant.h"

Enfant::Enfant(string _nom, Position _pos, Monde &_mde) : Element(_nom, _pos), Gaulois(_nom, _pos, AGE_ENFANT, _mde){
    evolvNbEnfant(1);
}

void Enfant::agir(){
    unsigned int indexRessource;
    evolution();
    getTrace().clear();
    if(Position::positionCorrecte(getPosition())){
        Position p(0, 0);
        p = vision(typeid(Baie));

        if(p.getX() != 0){
            indexRessource = mde->getCarte().find(p)->second;
            addFood(dynamic_cast<Ressource*>(mde->at(indexRessource))->getQte());
            //cout << getNom() << " : a trouve " << dynamic_cast<Ressource*>(mde->at(indexRessource))->getQte() <<" food " << p.getX() << ", " << p.getY() << endl;

            //Affichage Qt
            QString qstr = QString::fromStdString(getNom());
            getTrace().append(qstr);
            getTrace().append(" : a trouve ");
            getTrace().append(QString("%1").arg(dynamic_cast<Ressource*>(mde->at(indexRessource))->getQte()));
            getTrace().append(" food ");
            getTrace().append(QString("%1").arg(p.getX()));
            getTrace().append(", ");
            getTrace().append(QString("%1").arg(p.getY()));
            getTrace().append("\n");

            bouger(p, indexRessource);
            Baie::evolvNbBaie(-1);
        }
        else{
            bougerRandom();
        }

    }
}
