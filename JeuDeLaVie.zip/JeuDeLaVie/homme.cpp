#include "homme.h"

Homme::Homme(string _nom, Position _pos, Monde &_mde) : Element(_nom, _pos), Gaulois(_nom, _pos, AGE_ADULTE, _mde){
    evolvNbHomme(1);
}

void Homme::agir(){
    Gaulois::manger();
    Gaulois::construire();
    getTrace().clear();
    evolution();
    unsigned int indexRessource, indexFemme, sansResultat = 0;
    Position p(0, 0);
    if(Position::positionCorrecte(getPosition())){
        if(getFood() < ConfJeu::getCritic_food()){
            p = vision(typeid(Lapin));
            if(p.getX() != 0){
                indexRessource = mde->getCarte().find(p)->second;
                addFood(dynamic_cast<Ressource*>(mde->at(indexRessource))->getQte());
                //cout << getNom() << " : a trouve " << dynamic_cast<Ressource*>(mde->at(indexRessource))->getQte() <<" food " << p.getX() << ", " << p.getY() << endl;

                //Affichage Qt
                QString qstr = QString::fromStdString(getNom());
                getTrace().append(qstr);
                getTrace().append(" : a trouve ");
                getTrace().append(QString("%1").arg(dynamic_cast<Ressource*>(mde->at(indexRessource))->getQte()));
                getTrace().append(" food ");
                getTrace().append(QString("%1").arg(p.getX()));
                getTrace().append(", ");
                getTrace().append(QString("%1").arg(p.getY()));
                getTrace().append("\n");

                bouger(p, indexRessource);
                sansResultat = 1;
                Lapin::evolvNbLapin(-1);
            }
        }

        if(sansResultat == 0){
            if(getWood() < ConfJeu::getCritic_wood()){
                p = vision(typeid(Arbre));
                if(p.getX() != 0){
                    indexRessource = mde->getCarte().find(p)->second;
                    addWood(dynamic_cast<Ressource*>(mde->at(indexRessource))->getQte());
                    //cout << getNom() << " : a trouve " << dynamic_cast<Ressource*>(mde->at(indexRessource))->getQte() << " wood " << p.getX() << ", " << p.getY() << endl;

                    //Affichage Qt
                    QString qstr = QString::fromStdString(getNom());
                    getTrace().append(qstr);
                    getTrace().append(" : a trouve ");
                    getTrace().append(QString("%1").arg(dynamic_cast<Ressource*>(mde->at(indexRessource))->getQte()));
                    getTrace().append(" wood ");
                    getTrace().append(QString("%1").arg(p.getX()));
                    getTrace().append(", ");
                    getTrace().append(QString("%1").arg(p.getY()));
                    getTrace().append("\n");

                    bouger(p, indexRessource);
                    sansResultat = 1;
                    Arbre::evolvNbArbre(-1);
                }
            }
        }

        //Reproduction
        if(sansResultat == 0){
            if(Gaulois::getFood() > ConfJeu::getCritic_food()/2){
                p = vision(typeid(Femme));
                if(p.getX() !=0){
                    indexFemme = mde->getCarte().find(p)->second;
                    dynamic_cast<Femme*>(mde->at(indexFemme))->setAvoirEnfant(true);

                }
            }

        }

        if(sansResultat == 0){
            bougerRandom();
        }
    }
}
