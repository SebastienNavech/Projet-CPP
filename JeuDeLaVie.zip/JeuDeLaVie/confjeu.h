#ifndef CONFJEU_H
#define CONFJEU_H

#include "const.h"

class ConfJeu
{
    public:
        ConfJeu();
        void ConfJeu::init();

        static void setCritic_food(int);
        static void setCritic_wood(int);
        static void setFood_init(int);
        static void setWood_init(int);
        static void setHomme_min(int);
        static void setFemme_min(int);
        static void setLapin_min(int);
        static void setBaie_min(int);
        static void setArbre_min(int);
        static void setFood_pop(int);
        static void setWood_pop(int);
        static void setRomain_pop(int);

        static int getCritic_food();
        static int getCritic_wood();
        static int getFood_init();
        static int getWood_init();
        static int getHomme_min();
        static int getFemme_min();
        static int getLapin_min();
        static int getBaie_min();
        static int getArbre_min();
        static int getFood_pop();
        static int getWood_pop();
        static int getRomain_pop();

    private :
        static int critic_food, critic_wood;
        static int food_init, wood_init;
        static int homme_min, femme_min;
        static int lapin_min, baie_min, arbre_min, food_pop, wood_pop;
        static int romain_pop;

};

#endif // CONFJEU_H
