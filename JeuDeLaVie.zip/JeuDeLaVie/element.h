#ifndef ELEMENTS_H
#define ELEMENTS_H

#include <QtGui>
#include <string>
#include "position.h"
#include "const.h"

using namespace std;

class Element
{
    private :
		string nom;
		Position pos;
        QString trace;

	public :
        Element();
        Element(string, Position);
        virtual ~Element();
        virtual void agir() = 0;
        void setNom(string);
        void setPosition(Position);

        QString & getTrace();

        string getNom() const;
        Position getPosition() const;
        Position getPosition();

};

#endif
