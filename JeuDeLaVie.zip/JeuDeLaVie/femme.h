#ifndef FEMME_H
#define FEMME_H

#include "gaulois.h"
#include "lapin.h"
#include "baie.h"

class Femme : public Gaulois
{
    private :
        bool avoirEnfant;
    public:
        Femme(string, Position, Monde&);
        void agir();

        bool enGestation() const;
        void setAvoirEnfant(bool);
};

#endif // FEMME_H
