#ifndef GAULOIS_H
#define GAULOIS_H

#include "const.h"
#include "mobile.h"
#include "monde.h"

class Gaulois : public Mobile
{
    private :
        static int food;
        static int wood;
        static int peupleTotal;
        static int homme, femme, enfant;
	public :
        Gaulois(string, Position, int, Monde &);
        virtual void agir() = 0;
        static void calculPeuple();

        static void setFood(int qte);
        static void setWood(int qte);

        static int getFood();
        static int getWood();
        static int getHomme();
        static int getFemme();
        static int getEnfant();

        static void addFood(int);
        static void addWood(int);
        static void manger();
        static void construire();

        static void evolvNbHomme(int);
        static void evolvNbFemme(int);
        static void evolvNbEnfant(int);
};

#endif

