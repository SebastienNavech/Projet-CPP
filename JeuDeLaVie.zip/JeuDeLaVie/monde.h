#ifndef MONDE_H
#define MONDE_H

#include <QtGui>
#include <time.h>
#include "element.h"

using namespace std;

class Monde : private std::vector<Element*>
{
    private :
        map <Position, unsigned int> carte;
        static int cycle;
        static bool fin;
        QString trace;

    public :

        Monde();
        //~Monde();

        void evoluer();
        void repack();
        void rePeuplement();
        void supprimer(const int & index);
        void afficher();
        bool caseVide(int, int);

        QString& getTrace();

        static int getCycle();

        Position caseSuivante(Position actual, int sensX, int sensY);
        map<Position, unsigned int>& getCarte();

        Position generationAleatMap();

        void faireNaitre(Position p);
        bool estFini();

        vector<Element*>::at;
        vector<Element*>::size;
};

#endif

