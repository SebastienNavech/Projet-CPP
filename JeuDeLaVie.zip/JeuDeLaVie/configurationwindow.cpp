#include "configurationwindow.h"

QSpinBox *stockWood;
QSpinBox *stockFood;
QSpinBox *alertWood;
QSpinBox *alertFood;
QSpinBox *nbGaulois;
QSpinBox *nbGauloises;
QSpinBox *baies;
QSpinBox *lapins;
QSpinBox *arbres;
QSpinBox *food;
QSpinBox *wood;
QSpinBox *romains;

configurationWindow::configurationWindow() : QDialog()
{
    QTabWidget *onglets = new QTabWidget(this);
    onglets->setGeometry(15, 10, 400, 500);

    QWidget *page1 = new QWidget;
    QWidget *page2 = new QWidget;
    QPushButton *launchButton = new QPushButton("Launch simulation");
    QVBoxLayout *layoutPage1V1 = new QVBoxLayout;
    QVBoxLayout *layoutPage1V2 = new QVBoxLayout;
    QHBoxLayout *layoutPage1H1 = new QHBoxLayout;
    QVBoxLayout *primaryLayout = new QVBoxLayout;
    QVBoxLayout *layoutPage2V1 = new QVBoxLayout;
    QFormLayout *formSize = new QFormLayout;
    QFormLayout *formStocks = new QFormLayout;
    QFormLayout *formAlerts = new QFormLayout;
    QFormLayout *formPopulation = new QFormLayout;
    QFormLayout *formElements = new QFormLayout;
    QFormLayout *formPopFrequency = new QFormLayout;

    stockWood=new QSpinBox();
    stockFood=new QSpinBox();
    alertWood=new QSpinBox();
    alertFood=new QSpinBox();
    nbGaulois=new QSpinBox();
    nbGauloises=new QSpinBox();
    baies=new QSpinBox();
    lapins=new QSpinBox();
    arbres=new QSpinBox();
    food=new QSpinBox();
    wood=new QSpinBox();
    romains=new QSpinBox();

    QGroupBox *elementWorld = new QGroupBox("World's elements");
    QGroupBox *stocks = new QGroupBox("Stocks");
    QGroupBox *alerts = new QGroupBox("Alerts");
    QGroupBox *population = new QGroupBox("Population");
    QGroupBox *elements = new QGroupBox("Elements");
    QGroupBox *frequency = new QGroupBox("Frequency");

    stockWood->setValue(ConfJeu::getWood_init());
    stockFood->setValue(ConfJeu::getFood_init());
    alertWood->setValue(ConfJeu::getCritic_wood());
    alertFood->setValue(ConfJeu::getCritic_food());
    nbGaulois->setValue(ConfJeu::getHomme_min());
    nbGauloises->setValue(ConfJeu::getFemme_min());
    baies->setValue(ConfJeu::getBaie_min());
    lapins->setValue(ConfJeu::getLapin_min());
    arbres->setValue(ConfJeu::getArbre_min());
    food->setValue(ConfJeu::getFood_pop());
    wood->setValue(ConfJeu::getWood_pop());
    romains->setValue(ConfJeu::getRomain_pop());

    stockWood->setMaximum(1000);
    stockFood->setMaximum(1000);
    alertWood->setMaximum(1000);
    alertFood->setMaximum(1000);
    nbGaulois->setMaximum(40);
    nbGauloises->setMaximum(40);
    baies->setMaximum(40);
    lapins->setMaximum(40);
    arbres->setMaximum(40);
    food->setMaximum(20);
    wood->setMaximum(20);
    romains->setMaximum(20);


    formSize->addRow("Rabbit     ", lapins);
    formSize->addRow("Tree    ", arbres);

    formStocks->addRow("Wood     ", stockWood);
    formStocks->addRow("Food     ", stockFood);

    formAlerts->addRow("Wood      ", alertWood);
    formAlerts->addRow("Food      ", alertFood);

    formPopulation->addRow("Gallic   ", nbGaulois);
    formPopulation->addRow("Gallic Female ", nbGauloises);

    elementWorld->setLayout(formSize);
    stocks->setLayout(formStocks);
    alerts->setLayout(formAlerts);
    population->setLayout(formPopulation);

    layoutPage1V1->addWidget(elementWorld);
    layoutPage1V1->addWidget(stocks);
    layoutPage1V2->addWidget(alerts);
    layoutPage1V2->addWidget(population);

    layoutPage1H1->addLayout(layoutPage1V1);
    layoutPage1H1->addLayout(layoutPage1V2);

    page1->setLayout(layoutPage1H1);

    onglets->addTab(page1, "Game Properties");

    formElements->addRow("Berry", baies);

    formPopFrequency->addRow("Food", food);
    formPopFrequency->addRow("Wood", wood);
    formPopFrequency->addRow("Roman", romains);

    elements->setLayout(formElements);
    frequency->setLayout(formPopFrequency);
    layoutPage2V1->addWidget(elements);
    layoutPage2V1->addWidget(frequency);

    page2->setLayout(layoutPage2V1);

    onglets->addTab(page2, "Advanced");

    primaryLayout->addWidget(onglets);
    primaryLayout->addWidget(launchButton);

    this->setLayout(primaryLayout);

    QObject::connect(launchButton, SIGNAL(clicked()), this, SLOT(closeAndSave()));
}

void configurationWindow::closeAndSave(){
    ConfJeu::setWood_init(stockWood->value());
    ConfJeu::setFood_init( stockFood->value());
    ConfJeu::setCritic_wood(alertWood->value());
    ConfJeu::setCritic_food(alertFood->value());
    ConfJeu::setHomme_min(nbGaulois->value());
    ConfJeu::setFemme_min(nbGauloises->value());
    ConfJeu::setBaie_min(baies->value());
    ConfJeu::setLapin_min(lapins->value());
    ConfJeu::setArbre_min(arbres->value());
    ConfJeu::setFood_pop(food->value());
    ConfJeu::setWood_pop(wood->value());
    ConfJeu::setRomain_pop(romains->value());
    Gaulois::setFood(ConfJeu::getFood_init());
    Gaulois::setWood(ConfJeu::getWood_init());

    close();
}
