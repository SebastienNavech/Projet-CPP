#include "element.h"

Element::Element() : pos(), nom(){}
Element::Element(string _nom, Position _pos) : pos(_pos), nom(_nom) {}

Element::~Element(){ delete this; }

QString & Element::getTrace(){ return trace; }

void Element::setNom(string _nom){ nom=_nom; }
void Element::setPosition(Position _pos){ pos=_pos; }

string Element::getNom() const{ return nom; }
Position Element::getPosition() const{ return pos; }
Position Element::getPosition() { return pos; }


