#include "gamewindow.h"
#include <iostream>

gameWindow::gameWindow()
{
    int i,j,k,l;

    setFixedSize(LONGUEUR_MAP*33,125+LARGEUR_MAP*19);

    QMenu *menuFile = menuBar()->addMenu("&File");
    QAction *actionExit = new QAction("Exit", this);
    QAction *actionOneCycle = new QAction("+1", this);
    QAction *actionCycleTen = new QAction("+10", this);
    QAction *actionCycleOneHundred = new QAction("+100", this);
    QAction *actionInfos = new QAction("Infos", this);
    QAction *actionFin = new QAction("Fin", this);
    menuFile->addAction(actionOneCycle);
    menuFile->addAction(actionCycleTen);
    menuFile->addAction(actionCycleOneHundred);
    menuFile->addAction(actionInfos);
    menuFile->addAction(actionFin);
    menuFile->addAction(actionExit);

    QToolBar *toolBarFile = addToolBar("File");
    toolBarFile->addAction(actionOneCycle);
    toolBarFile->addAction(actionCycleTen);
    toolBarFile->addAction(actionCycleOneHundred);
    toolBarFile->addAction(actionInfos);
    toolBarFile->addAction(actionFin);
    actionOneCycle->setIcon(QIcon("evo1.png"));
    toolBarFile->setMovable(false);

    console=new QTextEdit(this);
    console->move(10, 15+LARGEUR_MAP*19);
    console->setReadOnly(true);
    console->setUpdatesEnabled(true);
    console->setFixedSize(400,100);

    QLabel *labelNbGaulois = new QLabel("Gaulois : ", this);
    labelNbGaulois->move(430, 15+LARGEUR_MAP*19);
    QLabel *labelNbGauloises = new QLabel("Gauloises : ", this);
    labelNbGauloises->move(430, 35+LARGEUR_MAP*19);
    QLabel *labelNbEnfants = new QLabel("Enfants : ", this);
    labelNbEnfants->move(430, 55+LARGEUR_MAP*19);
    QLabel *labelNbFood = new QLabel("Nourriture : ", this);
    labelNbFood->move(530, 15+LARGEUR_MAP*19);
    QLabel *labelNbWood = new QLabel("Bois : ", this);
    labelNbWood->move(530, 35+LARGEUR_MAP*19);
    QLabel *labelNbCycle = new QLabel("Ann�e : ", this);
    labelNbCycle->move(530, 55+LARGEUR_MAP*19);

    labelNbGauloisVal = new QLabel(nbGaulois, this);
    labelNbGauloisVal->move(490, 15+LARGEUR_MAP*19);
    labelNbGauloisesVal = new QLabel(nbGauloises, this);
    labelNbGauloisesVal->move(490, 35+LARGEUR_MAP*19);
    labelNbEnfantsVal = new QLabel(nbEnfants, this);
    labelNbEnfantsVal->move(490, 55+LARGEUR_MAP*19);
    labelNbFoodVal = new QLabel(nbFood, this);
    labelNbFoodVal->move(590, 15+LARGEUR_MAP*19);
    labelNbWoodVal = new QLabel(nbWood, this);
    labelNbWoodVal->move(590, 35+LARGEUR_MAP*19);
    labelNbCyclesVal = new QLabel(nbCycles, this);
    labelNbCyclesVal->move(590, 55+LARGEUR_MAP*19);


    QFrame *frameWorld = new QFrame(this);
    frameWorld->setFrameShape(QFrame::StyledPanel);
    frameWorld->setGeometry(0, 30+25, 31*LONGUEUR_MAP+10, LARGEUR_MAP*16+15);

    //print hexagones
    k=0;l=25+toolBarFile->height();
    for(i=1;i<LONGUEUR_MAP+1;i++){
       for(j=1;j<LARGEUR_MAP+1;j++){
           if(i%2 == 0 && j%2 == 0){
               label[i][j]= new QLabel(this);
               label[i][j]->setPixmap(QPixmap("hexagone.gif"));
               label[i][j]->move(k+31, l);
               k+=62;
           }
           if (i%2 == 1 && j%2 == 1){
               label[i][j]= new QLabel(this);
               label[i][j]->setPixmap(QPixmap("hexagone.gif"));
               label[i][j]->move(k, l);
               k+=62;
           }
        }
        l+=16;
        k=0;
    }
    refreshView();

    connect(actionExit, SIGNAL(triggered()), qApp, SLOT(quit()));

    connect(actionOneCycle, SIGNAL(triggered()), this, SLOT(evolvedOneCycle()));

    connect(actionCycleTen, SIGNAL(triggered()), this, SLOT(evolvedTenCycle()));

    connect(actionCycleOneHundred, SIGNAL(triggered()), this, SLOT(evolvedOneHundredCycle()));

    connect(actionInfos, SIGNAL(triggered()), this, SLOT(showInfos()));

    connect(actionFin, SIGNAL(triggered()), this, SLOT(evolvedFin()));


}

void gameWindow::evolvedOneCycle(){
    if(!md.estFini()){
        md.evoluer();
    }
    refreshView();
}


void gameWindow::evolvedTenCycle(){
    if(!md.estFini()){
        for(int active=0; active<10; active++){
            md.evoluer();
            refreshView();
            qApp->processEvents();
            Sleep(400);
        }
    }
}


void gameWindow::evolvedOneHundredCycle(){
    if(!md.estFini()){
        for(int active=0; active<100; active++){
            md.evoluer();
            refreshView();
            qApp->processEvents();
            Sleep(150);
        }
    }
}

void gameWindow::showInfos(){
    md.afficher();
    console->append(md.getTrace());
}

void gameWindow::evolvedFin(){
    while(!md.estFini()){
        md.evoluer();
        refreshView();
        qApp->processEvents();
        //Sleep(100);
    }
}

void gameWindow::refreshView(){
    int i, j;

    console->append(md.getTrace());

    nbGaulois=QString::number(Gaulois::getHomme());
    nbGauloises=QString::number(Gaulois::getFemme());
    nbEnfants=QString::number(Gaulois::getEnfant());
    nbFood=QString::number(Gaulois::getFood());
    nbWood=QString::number(Gaulois::getWood());
    nbCycles=QString::number(Monde::getCycle());

    labelNbGauloisVal->setText(nbGaulois);
    labelNbGauloisesVal->setText(nbGauloises);
    labelNbEnfantsVal->setText(nbEnfants);
    labelNbFoodVal->setText(nbFood);
    labelNbWoodVal->setText(nbWood);
    labelNbCyclesVal->setText(nbCycles);

    for(i=1;i<LONGUEUR_MAP+1;i++){
       for(j=1;j<LARGEUR_MAP+1;j++){
           if(i%2 == 0 && j%2 == 0){
               label[i][j]->setPixmap(QPixmap("hexagone.gif"));
           }
           if (i%2 == 1 && j%2 == 1){
               label[i][j]->setPixmap(QPixmap("hexagone.gif"));
           }
        }
    }
    map<Position, unsigned int>::iterator it;

    for(it = md.getCarte().begin(); it != md.getCarte().end(); it++){
        if(Position::positionCorrecte(it->first)){
            if(typeid(*md.at(it->second)) == typeid(Homme)){
                label[it->first.getY()][it->first.getX()]->setPixmap(QPixmap("g.gif"));
            }
            else{
                if(typeid(*md.at(it->second)) == typeid(Femme)){
                    label[it->first.getY()][it->first.getX()]->setPixmap(QPixmap("gf.gif"));
                }
                else{
                    if(typeid(*md.at(it->second)) == typeid(Arbre)){
                        label[it->first.getY()][it->first.getX()]->setPixmap(QPixmap("a.gif"));
                    }
                    else{
                        if(typeid(*md.at(it->second)) == typeid(Baie)){
                            label[it->first.getY()][it->first.getX()]->setPixmap(QPixmap("b.gif"));
                        }
                        else{
                            if(typeid(*md.at(it->second)) == typeid(Lapin)){
                                label[it->first.getY()][it->first.getX()]->setPixmap(QPixmap("l.gif"));
                            }
                            else{
                                if(typeid(*md.at(it->second)) == typeid(Romains)){
                                    label[it->first.getY()][it->first.getX()]->setPixmap(QPixmap("r.gif"));
                                }
                                else{
                                    if(typeid(*md.at(it->second)) == typeid(Enfant)){
                                        label[it->first.getY()][it->first.getX()]->setPixmap(QPixmap("e.gif"));
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}



