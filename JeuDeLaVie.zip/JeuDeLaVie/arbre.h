#ifndef ARBRES_H
#define ARBRES_H
#include "ressource.h"

class Arbre : public Ressource
{
    private :
        static int arbre;
    public :
        Arbre(Position);
        virtual ~Arbre();
        virtual void agir();
        static void evolvNbArbre(int);
        static int getArbre();
};

#endif


