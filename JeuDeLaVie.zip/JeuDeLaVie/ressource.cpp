#include "ressource.h"

Ressource::Ressource() : Element(){
    qteRessource = rand() % RESSOURCE_MAX + RESSOURCE_MIN;
}

Ressource::Ressource(string _nomRessource, Position _pos) : Element(_nomRessource, _pos){
    qteRessource = rand() % RESSOURCE_MAX + RESSOURCE_MIN;
}

Ressource::~Ressource(){
    delete this;
}

int Ressource::getQte() const{
    return qteRessource;
}

