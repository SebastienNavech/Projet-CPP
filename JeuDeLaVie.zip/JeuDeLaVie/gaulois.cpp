#include "gaulois.h"

int Gaulois::food = ConfJeu::getFood_init();
int Gaulois::wood = ConfJeu::getWood_init();
int Gaulois::peupleTotal = 0;
int Gaulois::homme = 0;
int Gaulois::femme = 0;
int Gaulois::enfant = 0;

Gaulois::Gaulois(string _nom, Position _pos, int _age, Monde &_mde) : Element(_nom, _pos), Mobile(_nom, _pos, _age, _mde){ peupleTotal++; }

void Gaulois::calculPeuple(){
    peupleTotal = homme + femme + enfant;
}

void Gaulois::setFood(int qte){ food = qte; }
void Gaulois::setWood(int qte){ wood = qte; }

int Gaulois::getFood(){ return food; }
int Gaulois::getWood(){ return wood; }

int Gaulois::getHomme(){ return homme; }
int Gaulois::getFemme(){ return femme; }
int Gaulois::getEnfant(){ return enfant; }

void Gaulois::addFood(int qte){ food += qte; }
void Gaulois::addWood(int qte){ wood += qte; }

void Gaulois::manger(){ food -= CONSO_FOOD; }
void Gaulois::construire(){ wood -= CONSO_WOOD; }

void Gaulois::evolvNbHomme(int nb){ homme += nb; }
void Gaulois::evolvNbFemme(int nb){ femme += nb; }
void Gaulois::evolvNbEnfant(int nb){ enfant += nb; }
