#ifndef LAPINS_H
#define LAPINS_H

#include "const.h"
#include "mobile.h"
#include "ressource.h"
#include "monde.h"

class Lapin : public Mobile, public Ressource
{
    private :
        static int lapin;
    public :
        Lapin(Position, Monde&);
        void agir();
        static void evolvNbLapin(int);
        static int getLapin();
};

#endif

