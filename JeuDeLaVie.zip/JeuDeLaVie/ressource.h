#ifndef RESSOURCES_H
#define RESSOURCES_H

#include "element.h"
#include <cstdlib>

class Ressource : public virtual Element
{
    private :
        int qteRessource;

	public :
        Ressource();
        Ressource(string, Position);
        virtual ~Ressource();
        int getQte() const;
        virtual void agir() = 0;
};

#endif
