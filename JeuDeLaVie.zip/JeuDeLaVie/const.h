#ifndef CONST_H
#define CONST_H

#define CF_RESSOURCE_CRITIC 50

#define CF_CONSO_FOOD 5
#define CF_CONSO_WOOD 5

#define CF_PEUPLE_HOMME_MIN 5
#define CF_PEUPLE_FEMME_MIN 5
#define CF_WOOD_REPOP 5
#define CF_FOOD_REPOP 5
#define CF_PREDATEUR_REPOP 1

#define DEBUT_MAP 1
#define LONGUEUR_MAP 20
#define LARGEUR_MAP 20

#define SENS_DBLE 2
#define SENS_PP 1
#define SENS_MM -1
#define SENS_NO 0

#define VITESSE_MIN 1
#define VITESSE_MAX 3

#define VUE_MIN 1
#define VUE_MAX 2

#define FORCE_MIN 1
#define FORCE_MAX 10

#define VIE_MIN 1
#define VIE_MAX 50

#define ESPERANCE_MIN 50
#define ESPERANCE_MAX 100

#define AGE_ENFANT 1
#define AGE_ADULTE 20

#define RESSOURCE_MIN 5
#define RESSOURCE_MAX 50


#define CONSO_FOOD 5
#define CONSO_WOOD 5

#define ELEMENT_MAX 20
#define PREDATEUR_MAX 5



#endif
