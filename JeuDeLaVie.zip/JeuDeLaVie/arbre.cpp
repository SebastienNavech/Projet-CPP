#include "arbre.h"

int Arbre::arbre = 0;

Arbre::Arbre(Position _pos) : Element("Arbre", _pos), Ressource("Arbre", _pos){ arbre++; }

Arbre::~Arbre(){}

void Arbre::agir(){}

void Arbre::evolvNbArbre(int nb){ arbre += nb; }

int Arbre::getArbre() { return arbre; }
